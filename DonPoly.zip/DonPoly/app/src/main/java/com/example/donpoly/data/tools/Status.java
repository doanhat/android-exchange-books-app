package com.example.donpoly.data.tools;

public enum Status {
    NEW,
    VERY_GOOD,
    GOOD,
    ACCEPTABLE
}
